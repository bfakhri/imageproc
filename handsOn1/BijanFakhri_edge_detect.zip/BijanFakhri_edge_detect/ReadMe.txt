// Bijan Fakhri
// Exercise 1.2
// 2-2-17

This code was written and tested on:
OS: Ubuntu 14.04.5 LTS
OpenCV: 3.1

To compile, 'cd' into the directory containing 'exercise1.2.cpp' and run the 'make' command. The makefile should compile the 'cpp' file and create an executable 'exercise1.2.exec'. 
To run, ensure that the 'bird.jpg' image is in the same directory as the executable. Then execute the command './exercise1.2.exec' and the program should run. 

The program will first display the original 'bird.jpg' image. The program will display the laplace, sobel, and canny edge map images each after the user presses a key. 
The program writes out each image to a 'jpg' file for later perusal. 
