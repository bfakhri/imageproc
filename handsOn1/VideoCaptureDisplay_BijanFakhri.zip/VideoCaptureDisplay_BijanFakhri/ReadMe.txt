// Bijan Fakhri
// Exercise 1.1
// 2-2-17

This code was written and tested on:
OS: Ubuntu 14.04.5 LTS
OpenCV: 3.1

To compile, 'cd' into the directory containing 'exercise1.1.cpp' and run the 'make' command. The makefile should compile the 'cpp' file and create an executable 'exercise1.1.exec'. 
To run, execute the command './exercise1.1.exec' and the program should run. 

The program will display a video stream from the webcam as well as a downsampled version of the stream. After collecting and displaying 200 frames, the program will have created a video file called 'Record.avi' of the downsampled stream. 
